LED6432Clock
============

LED6432点阵电子日历

视频地址：
http://v.youku.com/v_show/id_XNjQ4NjU0MTky.html
http://v.youku.com/v_show/id_XMzUyMDA2NDI0.html
